/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.prefs.Preferences;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import controller.TempController;

public class LimitsPreferencesWindow extends JFrame {

	private static final long serialVersionUID = -1374134281572167273L;
	Preferences preferences;
	ThermoGui tGui;
	TempController tC;
	JFrame limPrefFrame;
	JTextField recAdress;
	JTextField sendAdress;
	JTextField serverAdress;
	JTextField serverUser;
	JTextField serverPassword;
	JTextField limitIntervall;
	JTextField commandLine;
	JTextField commandIntervall;
	
	public LimitsPreferencesWindow(ThermoGui view, TempController tController) {
		super("Limitalarm Einstellungen");
		preferences = view.preferences;
		tGui = view;
		tC = tController;
		this.initWindow();
	}

	public void dialogOpen(String text) {
		JOptionPane.showMessageDialog(this, text);
	}

	private void initWindow() {
		limPrefFrame = new JFrame();
		limPrefFrame.setLayout(new GridLayout(11, 2));

		JLabel jL;

		jL = new JLabel();
		jL.setText("Empf�ngeradresse");
		limPrefFrame.add(jL);

		recAdress = new JTextField();
		limPrefFrame.add(recAdress);

		jL = new JLabel();
		jL.setText("Senderadresse");
		limPrefFrame.add(jL);

		sendAdress = new JTextField();
		limPrefFrame.add(sendAdress);

		jL = new JLabel();
		jL.setText("Mailserver");
		limPrefFrame.add(jL);

		serverAdress = new JTextField();
		limPrefFrame.add(serverAdress);

		jL = new JLabel();
		jL.setText("Mailuser");
		limPrefFrame.add(jL);

		serverUser = new JTextField();
		limPrefFrame.add(serverUser);

		jL = new JLabel();
		jL.setText("Mailpasswort");
		limPrefFrame.add(jL);

		serverPassword = new JTextField();	
		limPrefFrame.add(serverPassword);
		
		jL = new JLabel();
		jL.setText("Sendeintervall [s]");
		limPrefFrame.add(jL);

		limitIntervall = new JTextField();	
		limPrefFrame.add(limitIntervall);

		jL = new JLabel();
		jL.setText("");
		limPrefFrame.add(jL);
		
		jL = new JLabel();
		jL.setText("");
		limPrefFrame.add(jL);
		
		jL = new JLabel();
		jL.setText("Achtung - Expertenfunktion!");
		limPrefFrame.add(jL);
		
		jL = new JLabel();
		jL.setText("");
		limPrefFrame.add(jL);
		
		jL = new JLabel();
		jL.setText("Befehlsintervall [s]");
		limPrefFrame.add(jL);

		commandIntervall = new JTextField();	
		limPrefFrame.add(commandIntervall);
		
		jL = new JLabel();
		jL.setText("Befehlszeile");
		limPrefFrame.add(jL);

		commandLine = new JTextField();	
		limPrefFrame.add(commandLine);	
		
		
		JButton resetButton = new JButton();
		resetButton.setText("Reset");
		resetButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				recAdress.setText(preferences.get("limMailRec", "user@mbug.de"));
				sendAdress.setText(preferences.get("limMailSend", "user@mail.de"));
				serverAdress.setText(preferences.get("limMailServer", "smtp.mbug.de"));
				serverUser.setText(preferences.get("limMailUser", "user"));
				serverPassword.setText(preferences.get("limMailPass", "123456abc"));
				limitIntervall.setText(preferences.get("limitIntervall", "600"));
				commandIntervall.setText(preferences.get("commandIntervall", "3600"));
				commandLine.setText(preferences.get("commandLine", ""));
			}
		});

		JButton saveButton = new JButton();
		saveButton.setText("Speichern");
		saveButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				preferences.put("limMailRec", recAdress.getText());
				preferences.put("limMailSend", sendAdress.getText());
				preferences.put("limMailServer", serverAdress.getText());
				preferences.put("limMailUser", serverUser.getText());
				preferences.put("limMailPass", serverPassword.getText());
				preferences.put("limitIntervall", limitIntervall.getText());
				preferences.put("commandLine", commandLine.getText());
				preferences.put("commandIntervall", commandIntervall.getText());
				tC.mS.mailOnline = true;
				
				limPrefFrame.setVisible(false);
			}
		});

		limPrefFrame.add(saveButton);
		limPrefFrame.add(resetButton);

		recAdress.setText(preferences.get("limMailRec", "user@mbug.de"));
		sendAdress.setText(preferences.get("limMailSend", "user@mail.de"));
		serverAdress.setText(preferences.get("limMailServer", "smtp.mbug.de"));
		serverUser.setText(preferences.get("limMailUser", "user"));
		serverPassword.setText(preferences.get("limMailPass", "123456abc"));
		limitIntervall.setText(preferences.get("limitIntervall", "600"));
		commandIntervall.setText(preferences.get("commandIntervall", "3600"));
		commandLine.setText(preferences.get("commandLine", ""));

		limPrefFrame.pack();
		limPrefFrame.setVisible(true);
	}
}
