/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.prefs.Preferences;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class GeneralPreferencesWindow extends JFrame {

	private static final long serialVersionUID = -1365764281569167273L;
	ThermoGui tGui;

	Preferences preferences;

	int prefRefInt = 10;
	String pathToLog;
	boolean unixTime;
	boolean sendOnline;
	String sendOnlinePathString = "";

	JFrame prefFrame;

	JTextField refreshInterval;
	JCheckBox unixTimeBox;
	JCheckBox sendOnlineBox;
	JTextField sendOnlinePath;

	public  GeneralPreferencesWindow(ThermoGui view) {
		super("Generelle Einstellungen");
		preferences = view.preferences;
		prefRefInt = preferences.getInt("refInterval", 10);
		pathToLog = preferences.get("pathLog", "");
		sendOnline = preferences.getBoolean("sendOnline", false);
		sendOnlinePathString = preferences.get("sendOnlinePath", "");
		tGui = view;
		this.initWindow();
	}

	public void dialogOpen(String text) {
		JOptionPane.showMessageDialog(this, text);
	}

	private void initWindow() {
		prefFrame = new JFrame();
		prefFrame.setLayout(new GridLayout(5, 3));

		JLabel jL = new JLabel();
		jL.setText("Abrufintervall [* 100ms]");
		prefFrame.add(jL);

		refreshInterval = new JTextField();
		refreshInterval.setText(String.valueOf(prefRefInt));
		prefFrame.add(refreshInterval);

		jL = new JLabel();
		jL.setText("");
		prefFrame.add(jL);

		jL = new JLabel();
		jL.setText("Pfad f�r Logs");
		prefFrame.add(jL);

		jL = new JLabel();
		jL.setText(preferences.get("pathLog", "nicht angegeben"));
		prefFrame.add(jL);

		JButton logLocationButton = new JButton();
		logLocationButton.setText("Pfad angeben");
		logLocationButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				openLogPathDialog();
			}
		});

		prefFrame.add(logLocationButton);

		jL = new JLabel();
		jL.setText("Unixtimecode f�r Logs verwenden?");
		prefFrame.add(jL);

		jL = new JLabel();
		jL.setText("");
		prefFrame.add(jL);

		unixTimeBox = new JCheckBox();
		unixTimeBox.setSelected(preferences.getBoolean("logUnixTime", false));
		unixTimeBox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (unixTime) {
					unixTime = false;
				} else {
					unixTime = true;
				}
			}
		});

		prefFrame.add(unixTimeBox);

		jL = new JLabel();
		jL.setText("Werte online senden?");
		prefFrame.add(jL);

		sendOnlineBox = new JCheckBox();
		sendOnlineBox.setSelected(preferences.getBoolean("sendOnline", false));
		sendOnlineBox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (sendOnline) {
					sendOnline = false;
				} else {
					sendOnline = true;
				}
			}
		});

		prefFrame.add(sendOnlineBox);

		sendOnlinePath = new JTextField();
		sendOnlinePath.setText(sendOnlinePathString);
		prefFrame.add(sendOnlinePath);

		JButton resetButton = new JButton();
		resetButton.setText("Reset");
		resetButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				prefRefInt = preferences.getInt("refInterval", 10);
				refreshInterval.setText(String.valueOf(prefRefInt));
				unixTimeBox.setSelected(preferences.getBoolean("logUnixTime",
						false));
				sendOnlineBox.setSelected(preferences.getBoolean("sendOnline",
						false));
				sendOnlinePathString = preferences.get("sendOnlinePath", "");
				sendOnlinePath.setText(sendOnlinePathString);
			}
		});

		JButton saveButton = new JButton();
		saveButton.setText("Speichern");
		saveButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				int refreshValue = Integer.parseInt(refreshInterval.getText());
				preferences.putInt("refInterval", refreshValue);
				preferences.put("pathLog", pathToLog);
				preferences.putBoolean("logUnixTime", unixTime);
				preferences.putBoolean("sendOnline", sendOnline);
				preferences.put("sendOnlinePath", sendOnlinePath.getText());
				tGui.tController.getPreferences();
				tGui.tController.ready = true;

				prefFrame.setVisible(false);
			}
		});

		prefFrame.add(saveButton);
		prefFrame.add(resetButton);

		jL = new JLabel();
		jL.setText("");
		prefFrame.add(jL);

		prefFrame.pack();
		prefFrame.setVisible(true);
	}

	private void openLogPathDialog() {
		JFileChooser jF = new JFileChooser();
		jF.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int i = jF.showDialog(this, "Hier");
		if (i == JFileChooser.APPROVE_OPTION) {
			File file = jF.getSelectedFile();
			pathToLog = file.getPath();
			if (!file.canWrite()) {
				dialogOpen("In diesen Ordner darf nicht geschrieben werden!");
			}
		}
	}
}
