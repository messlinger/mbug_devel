/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package gui;

import java.awt.Checkbox;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.prefs.Preferences;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.RecordFileController;
import controller.TempController;

public class ThermoGui extends JFrame {

	private static final long serialVersionUID = -3726932491405454804L;

	public List<Integer> limitedFields;
	public Map<Integer, JTextField> loggedFields;
	public TempController tController;
	public Preferences preferences;

	public JTextField tempAnzeige1;
	public JTextField tempAnzeige2;
	public JTextField tempAnzeige3;
	public JTextField tempAnzeige4;
	public JTextField tempAnzeige5;
	public JTextField tempAnzeige6;
	public JTextField tempAnzeige7;
	public JTextField tempAnzeige8;

	JTextField tempLimUp1;
	JTextField tempLimUp2;
	JTextField tempLimUp3;
	JTextField tempLimUp4;
	JTextField tempLimUp5;
	JTextField tempLimUp6;
	JTextField tempLimUp7;
	JTextField tempLimUp8;

	JTextField tempLimDown1;
	JTextField tempLimDown2;
	JTextField tempLimDown3;
	JTextField tempLimDown4;
	JTextField tempLimDown5;
	JTextField tempLimDown6;
	JTextField tempLimDown7;
	JTextField tempLimDown8;

	public void setMessageText(String messageText) {
		JOptionPane.showMessageDialog(this, messageText);
	}

	public String getTempAnzeige1() {
		return tempAnzeige1.getText();
	}

	public void setTempAnzeige1(String messageText) {
		this.tempAnzeige1.setText(messageText);
	}

	public String getTempAnzeige2() {
		return tempAnzeige2.getText();
	}

	public void setTempAnzeige2(String messageText) {
		this.tempAnzeige2.setText(messageText);
	}

	public String getTempAnzeige3() {
		return tempAnzeige3.getText();
	}

	public void setTempAnzeige3(String messageText) {
		this.tempAnzeige3.setText(messageText);
	}

	public String getTempAnzeige4() {
		return tempAnzeige4.getText();
	}

	public void setTempAnzeige4(String messageText) {
		this.tempAnzeige4.setText(messageText);
	}

	public String getTempAnzeige5() {
		return tempAnzeige5.getText();
	}

	public void setTempAnzeige5(String messageText) {
		this.tempAnzeige5.setText(messageText);
	}

	public String getTempAnzeige6() {
		return tempAnzeige6.getText();
	}

	public void setTempAnzeige6(String messageText) {
		this.tempAnzeige6.setText(messageText);
	}

	public String getTempAnzeige7() {
		return tempAnzeige7.getText();
	}

	public void setTempAnzeige7(String messageText) {
		this.tempAnzeige7.setText(messageText);
	}

	public String getTempAnzeige8() {
		return tempAnzeige8.getText();
	}

	public void setTempAnzeige8(String messageText) {
		this.tempAnzeige8.setText(messageText);
	}

	public String getTempLimUp1() {
		return tempLimUp1.getText();
	}

	public void setTempLimUp1(String messageText) {
		this.tempLimUp1.setText(messageText);
	}

	public String getTempLimUp2() {
		return tempLimUp2.getText();
	}

	public void setTempLimUp2(String messageText) {
		this.tempLimUp2.setText(messageText);
	}

	public String getTempLimUp3() {
		return tempLimUp3.getText();
	}

	public void setTempLimUp3(String messageText) {
		this.tempLimUp3.setText(messageText);
	}

	public String getTempLimUp4() {
		return tempLimUp4.getText();
	}

	public void setTempLimUp4(String messageText) {
		this.tempLimUp4.setText(messageText);
	}

	public String getTempLimUp5() {
		return tempLimUp5.getText();
	}

	public void setTempLimUp5(String messageText) {
		this.tempLimUp5.setText(messageText);
	}

	public String getTempLimUp6() {
		return tempLimUp6.getText();
	}

	public void setTempLimUp6(String messageText) {
		this.tempLimUp6.setText(messageText);
	}

	public String getTempLimUp7() {
		return tempLimUp7.getText();
	}

	public void setTempLimUp7(String messageText) {
		this.tempLimUp7.setText(messageText);
	}

	public String getTempLimUp8() {
		return tempLimUp8.getText();
	}

	public void setTempLimUp8(String messageText) {
		this.tempLimUp8.setText(messageText);
	}

	public String getTempLimDown1() {
		return tempLimDown1.getText();
	}

	public void setTempLimDown1(String messageText) {
		this.tempLimDown1.setText(messageText);
	}

	public String getTempLimDown2() {
		return tempLimDown2.getText();
	}

	public void setTempLimDown2(String messageText) {
		this.tempLimDown2.setText(messageText);
	}

	public String getTempLimDown3() {
		return tempLimDown3.getText();
	}

	public void setTempLimDown3(String messageText) {
		this.tempLimDown3.setText(messageText);
	}

	public String getTempLimDown4() {
		return tempLimDown4.getText();
	}

	public void setTempLimDown4(String messageText) {
		this.tempLimDown4.setText(messageText);
	}

	public String getTempLimDown5() {
		return tempLimDown5.getText();
	}

	public void setTempLimDown5(String messageText) {
		this.tempLimDown5.setText(messageText);
	}

	public String getTempLimDown6() {
		return tempLimDown6.getText();
	}

	public void setTempLimDown6(String messageText) {
		this.tempLimDown6.setText(messageText);
	}

	public String getTempLimDown7() {
		return tempLimDown7.getText();
	}

	public void setTempLimDown7(String messageText) {
		this.tempLimDown7.setText(messageText);
	}

	public String getTempLimDown8() {
		return tempLimDown8.getText();
	}

	public void setTempLimDown8(String messageText) {
		this.tempLimDown8.setText(messageText);
	}

	public Checkbox tempLog1;
	public Checkbox tempLog2;
	public Checkbox tempLog3;
	public Checkbox tempLog4;
	public Checkbox tempLog5;
	public Checkbox tempLog6;
	public Checkbox tempLog7;
	public Checkbox tempLog8;

	Checkbox tempLim1;
	Checkbox tempLim2;
	Checkbox tempLim3;
	Checkbox tempLim4;
	Checkbox tempLim5;
	Checkbox tempLim6;
	Checkbox tempLim7;
	Checkbox tempLim8;

	public ThermoGui(String name) {
		super(name);

		this.createRootPane().setLayout(null);

		this.initWindow();

		this.addWindowListener(new WindowListener() {

			public void windowClosed(WindowEvent arg0) {
			}

			public void windowActivated(WindowEvent e) {

			}

			public void windowClosing(WindowEvent e) {
				cleanUpLoggers();
				System.exit(0);
			}

			public void windowDeactivated(WindowEvent e) {

			}

			public void windowDeiconified(WindowEvent e) {

			}

			public void windowIconified(WindowEvent e) {

			}

			public void windowOpened(WindowEvent e) {
			}

		});

		limitedFields = new LinkedList<Integer>();
		loggedFields = new HashMap<Integer, JTextField>();

		preferences = Preferences.userRoot().node(this.getClass().getName());
	}

	ItemListener limitBoxListener = new ItemListener() {

		@Override
		public void itemStateChanged(ItemEvent e) {
			JTextField actualTempField = new JTextField();
			JTextField limUp = new JTextField();
			JTextField limDown = new JTextField();
			Checkbox cb = (Checkbox) e.getSource();
			int cbNumber = Integer.valueOf((cb.getName()).replace("lim", ""));
			// messageText.setText(String.valueOf(cbNumber));
			switch (cbNumber) {
			case 1:
				actualTempField = tempAnzeige1;
				limUp = tempLimUp1;
				limDown = tempLimDown1;
				break;

			case 2:
				actualTempField = tempAnzeige2;
				limUp = tempLimUp2;
				limDown = tempLimDown2;
				break;

			case 3:
				actualTempField = tempAnzeige3;
				limUp = tempLimUp3;
				limDown = tempLimDown3;
				break;

			case 4:
				actualTempField = tempAnzeige4;
				limUp = tempLimUp4;
				limDown = tempLimDown4;
				break;

			case 5:
				actualTempField = tempAnzeige5;
				limUp = tempLimUp5;
				limDown = tempLimDown5;
				break;

			case 6:
				actualTempField = tempAnzeige6;
				limUp = tempLimUp6;
				limDown = tempLimDown6;
				break;

			case 7:
				actualTempField = tempAnzeige7;
				limUp = tempLimUp7;
				limDown = tempLimDown7;
				break;

			case 8:
				actualTempField = tempAnzeige8;
				limUp = tempLimUp8;
				limDown = tempLimDown8;
				break;
			default:
				break;
			}
			String actualTempString = actualTempField.getText();
			if (!actualTempString.equals("")) {
				float actualTemp = Float.parseFloat(actualTempString);
				synchronized (limitedFields) {
					if (e.getStateChange() == 1) {
						limDown.setEnabled(true);
						limUp.setEnabled(true);
						limDown.setText(String.valueOf(actualTemp - 10));
						limUp.setText(String.valueOf(actualTemp + 10));
						int field = cbNumber;
						if (!limitedFields.contains(field)) {
							limitedFields.add(field);
						}
					} else if (e.getStateChange() == 2) {
						limDown.setEnabled(false);
						limUp.setEnabled(false);
						actualTempField.setBackground(null);
						int field = cbNumber;
						if (limitedFields.contains(field)) {
							limitedFields.remove(limitedFields.indexOf(field));
						}
					}
				}
			} else {
				setMessageText("Bitte Sensor anschlie�en!");
				cb.setState(false);
			}
		}
	};

	ItemListener logBoxListener = new ItemListener() {

		@Override
		public void itemStateChanged(ItemEvent e) {
			// JTextField actualTempField = new JTextField();
			Checkbox cb = (Checkbox) e.getSource();
			int cbNumber = Integer.valueOf((cb.getName()).replace("log", ""));
			// messageText.setText(String.valueOf(cbNumber));
			JTextField actualTempField = new JTextField();
			switch (cbNumber) {
			case 1:
				actualTempField = tempAnzeige1;
				break;

			case 2:
				actualTempField = tempAnzeige2;
				break;

			case 3:
				actualTempField = tempAnzeige3;
				break;

			case 4:
				actualTempField = tempAnzeige4;
				break;

			case 5:
				actualTempField = tempAnzeige5;
				break;

			case 6:
				actualTempField = tempAnzeige6;
				break;

			case 7:
				actualTempField = tempAnzeige7;
				break;

			case 8:
				actualTempField = tempAnzeige8;
				break;
			default:
				break;
			}

			if (!actualTempField.getText().equals("")) {
				if (e.getStateChange() == 1) {
					if (!loggedFields.containsValue(actualTempField)) {
						loggedFields.put(cbNumber, actualTempField);
					}
				} else if (e.getStateChange() == 2) {
					if (loggedFields.containsValue(actualTempField)) {
						loggedFields.remove(cbNumber);
					}
				}
			} else {
				setMessageText("Bitte Sensor anschlie�en!");
				cb.setState(false);
			}
		}
	};

	public void cleanUpLoggers() {
		loggedFields.clear();
		for (Entry<Integer, RecordFileController> entry : tController.fileController
				.entrySet()) {
			RecordFileController rFC = entry.getValue();
			rFC.closeWriters();
		}
	}

	public void limitController() {
		synchronized (limitedFields) {
			for (int field : limitedFields) {
				try {
					switch (field) {

					case 1:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp1()),
								Float.parseFloat(getTempLimDown1()),
								tController.tempValues[0], tempAnzeige1);
						break;
					case 2:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp2()),
								Float.parseFloat(getTempLimDown2()),
								tController.tempValues[1], tempAnzeige2);
						break;
					case 3:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp3()),
								Float.parseFloat(getTempLimDown3()),
								tController.tempValues[2], tempAnzeige3);
						break;
					case 4:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp4()),
								Float.parseFloat(getTempLimDown4()),
								tController.tempValues[3], tempAnzeige4);
						break;
					case 5:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp5()),
								Float.parseFloat(getTempLimDown5()),
								tController.tempValues[4], tempAnzeige5);
						break;
					case 6:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp6()),
								Float.parseFloat(getTempLimDown6()),
								tController.tempValues[5], tempAnzeige6);
						break;
					case 7:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp7()),
								Float.parseFloat(getTempLimDown7()),
								tController.tempValues[6], tempAnzeige7);
						break;
					case 8:
						tController.checkLimits(
								Float.parseFloat(getTempLimUp8()),
								Float.parseFloat(getTempLimDown8()),
								tController.tempValues[7], tempAnzeige8);
						break;
					}
				} catch (Exception e) {
					// Kein Handling
				}
			}
			tController.ready = true;
		}
	}

	protected void initWindow() {
		JPanel valuePanel = new JPanel(new GridLayout(9, 6, 10, 10));

		tempAnzeige1 = new JTextField();
		tempAnzeige1.setName("1");

		tempAnzeige2 = new JTextField();
		tempAnzeige2.setName("2");

		tempAnzeige3 = new JTextField();
		tempAnzeige3.setName("3");

		tempAnzeige4 = new JTextField();
		tempAnzeige4.setName("4");

		tempAnzeige5 = new JTextField();
		tempAnzeige5.setName("5");

		tempAnzeige6 = new JTextField();
		tempAnzeige6.setName("6");

		tempAnzeige7 = new JTextField();
		tempAnzeige7.setName("7");

		tempAnzeige8 = new JTextField();
		tempAnzeige8.setName("8");

		tempLimUp1 = new JTextField();
		tempLimUp1.setEnabled(false);
		tempLimUp2 = new JTextField();
		tempLimUp2.setEnabled(false);
		tempLimUp3 = new JTextField();
		tempLimUp3.setEnabled(false);
		tempLimUp4 = new JTextField();
		tempLimUp4.setEnabled(false);
		tempLimUp5 = new JTextField();
		tempLimUp5.setEnabled(false);
		tempLimUp6 = new JTextField();
		tempLimUp6.setEnabled(false);
		tempLimUp7 = new JTextField();
		tempLimUp7.setEnabled(false);
		tempLimUp8 = new JTextField();
		tempLimUp8.setEnabled(false);

		tempLimDown1 = new JTextField();
		tempLimDown1.setEnabled(false);
		tempLimDown2 = new JTextField();
		tempLimDown2.setEnabled(false);
		tempLimDown3 = new JTextField();
		tempLimDown3.setEnabled(false);
		tempLimDown4 = new JTextField();
		tempLimDown4.setEnabled(false);
		tempLimDown5 = new JTextField();
		tempLimDown5.setEnabled(false);
		tempLimDown6 = new JTextField();
		tempLimDown6.setEnabled(false);
		tempLimDown7 = new JTextField();
		tempLimDown7.setEnabled(false);
		tempLimDown8 = new JTextField();
		tempLimDown8.setEnabled(false);

		tempLog1 = new Checkbox("Log");
		tempLog1.setName("log1");
		tempLog1.addItemListener(logBoxListener);

		tempLog2 = new Checkbox("Log");
		tempLog2.setName("log2");
		tempLog2.addItemListener(logBoxListener);

		tempLog3 = new Checkbox("Log");
		tempLog3.setName("log3");
		tempLog3.addItemListener(logBoxListener);

		tempLog4 = new Checkbox("Log");
		tempLog4.setName("log4");
		tempLog4.addItemListener(logBoxListener);

		tempLog5 = new Checkbox("Log");
		tempLog5.setName("log5");
		tempLog5.addItemListener(logBoxListener);

		tempLog6 = new Checkbox("Log");
		tempLog6.setName("log6");
		tempLog6.addItemListener(logBoxListener);

		tempLog7 = new Checkbox("Log");
		tempLog7.setName("log7");
		tempLog7.addItemListener(logBoxListener);

		tempLog8 = new Checkbox("Log");
		tempLog8.setName("log8");
		tempLog8.addItemListener(logBoxListener);

		tempLim1 = new Checkbox("Limit");
		tempLim1.setName("lim1");
		tempLim1.addItemListener(limitBoxListener);

		tempLim2 = new Checkbox("Limit");
		tempLim2.setName("lim2");
		tempLim2.addItemListener(limitBoxListener);

		tempLim3 = new Checkbox("Limit");
		tempLim3.setName("lim3");
		tempLim3.addItemListener(limitBoxListener);

		tempLim4 = new Checkbox("Limit");
		tempLim4.setName("lim4");
		tempLim4.addItemListener(limitBoxListener);

		tempLim5 = new Checkbox("Limit");
		tempLim5.setName("lim5");
		tempLim5.addItemListener(limitBoxListener);

		tempLim6 = new Checkbox("Limit");
		tempLim6.setName("lim6");
		tempLim6.addItemListener(limitBoxListener);

		tempLim7 = new Checkbox("Limit");
		tempLim7.setName("lim7");
		tempLim7.addItemListener(limitBoxListener);

		tempLim8 = new Checkbox("Limit");
		tempLim8.setName("lim8");
		tempLim8.addItemListener(limitBoxListener);

		JLabel textAnzeigeLabel1 = new JLabel();
		textAnzeigeLabel1.setText("Sensor 1");
		tempAnzeige1.setEditable(false);

		JLabel textAnzeigeLabel2 = new JLabel();
		textAnzeigeLabel2.setText("Sensor 2");
		tempAnzeige2.setEditable(false);

		JLabel textAnzeigeLabel3 = new JLabel();
		textAnzeigeLabel3.setText("Sensor 3");
		tempAnzeige3.setEditable(false);

		JLabel textAnzeigeLabel4 = new JLabel();
		textAnzeigeLabel4.setText("Sensor 4");
		tempAnzeige4.setEditable(false);

		JLabel textAnzeigeLabel5 = new JLabel();
		textAnzeigeLabel5.setText("Sensor 5");
		tempAnzeige5.setEditable(false);

		JLabel textAnzeigeLabel6 = new JLabel();
		textAnzeigeLabel6.setText("Sensor 6");
		tempAnzeige6.setEditable(false);

		JLabel textAnzeigeLabel7 = new JLabel();
		textAnzeigeLabel7.setText("Sensor 7");
		tempAnzeige7.setEditable(false);

		JLabel textAnzeigeLabel8 = new JLabel();
		textAnzeigeLabel8.setText("Sensor 8");
		tempAnzeige8.setEditable(false);

		JLabel titelLabel1 = new JLabel();
		titelLabel1.setText("Sensor");

		JLabel titelLabel2 = new JLabel();
		titelLabel2.setText("Wert");

		JLabel titelLabel3 = new JLabel();
		titelLabel3.setText("Limit");

		JLabel titelLabel4 = new JLabel();
		titelLabel4.setText("Obergrenze");

		JLabel titelLabel5 = new JLabel();
		titelLabel5.setText("Untergrenze");

		JLabel titelLabel6 = new JLabel();
		titelLabel6.setText("Protokollierung");

		valuePanel.add(titelLabel1);
		valuePanel.add(titelLabel2);
		valuePanel.add(titelLabel3);
		valuePanel.add(titelLabel4);
		valuePanel.add(titelLabel5);
		valuePanel.add(titelLabel6);

		valuePanel.add(textAnzeigeLabel1);
		valuePanel.add(tempAnzeige1);
		valuePanel.add(tempLim1);
		valuePanel.add(tempLimUp1);
		valuePanel.add(tempLimDown1);
		valuePanel.add(tempLog1);

		valuePanel.add(textAnzeigeLabel2);
		valuePanel.add(tempAnzeige2);
		valuePanel.add(tempLim2);
		valuePanel.add(tempLimUp2);
		valuePanel.add(tempLimDown2);
		valuePanel.add(tempLog2);

		valuePanel.add(textAnzeigeLabel3);
		valuePanel.add(tempAnzeige3);
		valuePanel.add(tempLim3);
		valuePanel.add(tempLimUp3);
		valuePanel.add(tempLimDown3);
		valuePanel.add(tempLog3);

		valuePanel.add(textAnzeigeLabel4);
		valuePanel.add(tempAnzeige4);
		valuePanel.add(tempLim4);
		valuePanel.add(tempLimUp4);
		valuePanel.add(tempLimDown4);
		valuePanel.add(tempLog4);

		valuePanel.add(textAnzeigeLabel5);
		valuePanel.add(tempAnzeige5);
		valuePanel.add(tempLim5);
		valuePanel.add(tempLimUp5);
		valuePanel.add(tempLimDown5);
		valuePanel.add(tempLog5);

		valuePanel.add(textAnzeigeLabel6);
		valuePanel.add(tempAnzeige6);
		valuePanel.add(tempLim6);
		valuePanel.add(tempLimUp6);
		valuePanel.add(tempLimDown6);
		valuePanel.add(tempLog6);

		valuePanel.add(textAnzeigeLabel7);
		valuePanel.add(tempAnzeige7);
		valuePanel.add(tempLim7);
		valuePanel.add(tempLimUp7);
		valuePanel.add(tempLimDown7);
		valuePanel.add(tempLog7);

		valuePanel.add(textAnzeigeLabel8);
		valuePanel.add(tempAnzeige8);
		valuePanel.add(tempLim8);
		valuePanel.add(tempLimUp8);
		valuePanel.add(tempLimDown8);
		valuePanel.add(tempLog8);

		JMenuBar menuBar;
		JMenu menu;
		JMenuItem menuItem;

		menuBar = new JMenuBar();
		menu = new JMenu("Einstellungen");
		menuBar.add(menu);

		ActionListener menuActionListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String sourceName = ((JMenuItem) e.getSource()).getName();
				if (sourceName.equals("general")) {
					tController.openGeneralPrefWindow();
				} else if (sourceName.equals("limit")) {
					tController.openLimitsPrefWindow();
				}
			}
		};

		menuItem = new JMenuItem("Generelle Einstellungen");
		menuItem.setName("general");
		menuItem.addActionListener(menuActionListener);
		menu.add(menuItem);

		menuItem = new JMenuItem("Limitwarnung Einstellungen");
		menuItem.setName("limit");
		menuItem.addActionListener(menuActionListener);
		menu.add(menuItem);

		this.getContentPane().add(valuePanel);
		this.setJMenuBar(menuBar);
		this.pack();
	}
}