/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package gui;

import controller.TempController;

public class MainGUI {

	public static void main(String[] args) {
		ThermoGui view = new ThermoGui("USB-Thermometer mbug2818");
		view.setBounds(10, 10, 600, 550);
		view.setVisible(true);

		TempController tempController = new TempController(view);
		view.tController = tempController;

		tempController.start();
	}
}