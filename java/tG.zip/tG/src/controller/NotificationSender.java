/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package controller;

import gui.ThermoGui;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

public class NotificationSender {

	private ThermoGui tGui;
	private TempController tC;
	public boolean mailOnline = true;
	private Date[] lastMail = new Date[8];
	private Date[] lastCommand = new Date[8];
	private String[] commands;
	private long limitIntervall;
	private long commandIntervall;

	public NotificationSender(ThermoGui g, TempController tController) {
		tGui = g;
		tC = tController;
		limitIntervall = tGui.preferences.getInt("limitIntervall", 600);
		
		String commandString = tGui.preferences.get("commandLine", "");
		commands = commandString.split(";");
		commandIntervall = tGui.preferences.getInt("commandIntervall", 3600);
	}

	public void sendNotification(String sensorName, float tempValue,
			float tempLimit) {
		sendMail(sensorName, tempValue, tempLimit);
		executeCommand(sensorName, tempValue, tempLimit);
	}

	public void sendMail(String sensorName, float tempValue, float tempLimit) {
		SimpleEmail mailToSend = new SimpleEmail();
		int a = Integer.parseInt(sensorName) - 1;
		if (mailOnline && limitMailTimeIntervall(a)) {
			try {
				mailToSend.setHostName(tGui.preferences
						.get("limMailServer", ""));
				mailToSend.setFrom(tGui.preferences.get("limMailSend", ""));
				mailToSend.setAuthentication(
						tGui.preferences.get("limMailUser", ""),
						tGui.preferences.get("limMailPass", ""));
				mailToSend.setSubject("Wert�berschreitung im Sensor "
						+ sensorName);
				String mailText = "Fehler!\nSensor " + sensorName
						+ " hat folgenden Wert nicht eingehalten: " + tempLimit
						+ "\nDer jetzige Wert ist " + tempValue;
				mailToSend.setMsg(mailText);
				mailToSend.addTo(tGui.preferences.get("limMailRec", ""));
				mailToSend.send();
				lastMail[a] = new Date();
			} catch (EmailException e) {
				tGui.setMessageText(e.getMessage());
				mailOnline = false;
				tC.openLimitsPrefWindow();
			}
		}
	}

	public void executeCommand(String sensorName, float tempValue,
			float tempLimit) {
		int a = Integer.parseInt(sensorName) - 1;
		if (commands.length >= 1 && limitCommandTimeIntervall(a)) {
			File rF = new File("commands_log.txt");

			FileWriter fW;
			BufferedWriter bW;

			SimpleDateFormat sDF;

			Date date = new Date();
			sDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");

			for (String command : commands) {
				String commandReplacedValues = command.replace("[SENSOR]",
						sensorName);
				commandReplacedValues = commandReplacedValues.replace(
						"[VALUE]", String.valueOf(tempValue));
				commandReplacedValues = commandReplacedValues.replace(
						"[LIMIT]", String.valueOf(tempLimit));
				try {
					Process process = Runtime.getRuntime().exec(
							commandReplacedValues);
					InputStream outS = process.getInputStream();
					String outString = "";
					byte[] outBytes = new byte[1024];
					while (outS.read(outBytes, 0, 1024) > 0) {
						outString += new String(outBytes);
					}

					try {
						fW = new FileWriter(rF, true);
						bW = new BufferedWriter(fW);
						bW.write(sDF.format(date) + " - " + outString);
						bW.newLine();
						bW.close();
						fW.close();
					} catch (Exception e) {
					}

				} catch (IOException e) {
					tC.openDialog(e.getMessage());
				}
			}
			lastCommand[a] = new Date();
		}
	}

	private boolean limitMailTimeIntervall(int sensor) {
		Date now = new Date();
		if (lastMail[sensor] == null
				|| (now.getTime() - lastMail[sensor].getTime() >= limitIntervall * 1000)) {
			return true;
		}
		return false;
	}

	private boolean limitCommandTimeIntervall(int sensor) {
		Date now = new Date();
		if (lastCommand[sensor] == null
				|| (now.getTime() - lastCommand[sensor].getTime() >= commandIntervall * 1000)) {
			return true;
		}
		return false;
	}
}
