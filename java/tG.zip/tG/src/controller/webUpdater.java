/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class webUpdater {

	String urlToSend;
	TempController tC;
	
	public webUpdater(String url, TempController tempC){
		urlToSend = url;
		tC = tempC;
	}
	
	public void sendDataOnline(){
		URL url;
		try {
			url = new URL(urlToSend+"?v1="+String.valueOf(tC.tempValues[0])+"&v2="+String.valueOf(tC.tempValues[1])+"&v3="+String.valueOf(tC.tempValues[2])+"&v4="+String.valueOf(tC.tempValues[3])+"&v5="+String.valueOf(tC.tempValues[4])+"&v6="+String.valueOf(tC.tempValues[5])+"&v7="+String.valueOf(tC.tempValues[6])+"&v8="+String.valueOf(tC.tempValues[7]));
			url.openStream();
		} catch (MalformedURLException e) {
			tC.openGeneralPrefWindow();
		} catch (IOException e) {
			tC.openGeneralPrefWindow();
		}
	}
}
