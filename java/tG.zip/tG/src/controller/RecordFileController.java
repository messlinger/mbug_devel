/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package controller;

import gui.ThermoGui;

import java.awt.Checkbox;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RecordFileController {

	ThermoGui tGui;
	int fieldToLogId;
	FileWriter fW;
	BufferedWriter bW;
	String loggingPath;
	boolean unixTime;
	Checkbox loggingBox;
	SimpleDateFormat sDF;
	int entryCounter = 0;

	public RecordFileController(ThermoGui view, int logId, String logPath,
			boolean recUnixTime) {
		tGui = view;
		fieldToLogId = logId;
		loggingPath = logPath;
		unixTime = recUnixTime;
		createFile();
		switch (fieldToLogId) {
		case 1:
			loggingBox = tGui.tempLog1;
			break;
		case 2:
			loggingBox = tGui.tempLog2;
			break;
		case 3:
			loggingBox = tGui.tempLog3;
			break;
		case 4:
			loggingBox = tGui.tempLog4;
			break;
		case 5:
			loggingBox = tGui.tempLog5;
			break;
		case 6:
			loggingBox = tGui.tempLog6;
			break;
		case 7:
			loggingBox = tGui.tempLog7;
			break;
		case 8:
			loggingBox = tGui.tempLog8;
			break;
		}
	}

	Color red = new Color(255, 0, 0);
	Color green = new Color(0, 255, 0);
	Color blue = new Color(41, 21, 0);

	private void createFile() {
		if (!loggingPath.isEmpty()) {
			loggingPath = loggingPath + "\\";
		}
		Date date = new Date();
		SimpleDateFormat sDF = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sDF.format(date);
		String fileName = loggingPath + "data_sensor" + fieldToLogId + "_"
				+ dateString + ".csv";
		File rF = new File(fileName);
		try {
			fW = new FileWriter(rF, true);
			bW = new BufferedWriter(fW);
		} catch (IOException e) {
			loggingBox.setBackground(red);
			tGui.setMessageText(e.getMessage());
		}
	}

	public boolean logToFile(float value) {
		loggingBox.setBackground(green);
		Date date = new Date();
		if (entryCounter >= 10) {
			closeWriters();
			loggingBox.setBackground(blue);
			createFile();
			entryCounter = 0;
		}
		try {
			String dateString = "";
			if (unixTime) {
				dateString = String.valueOf(date.getTime());
			} else {
				sDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
				dateString = sDF.format(date);
			}
			bW.write(dateString);
			bW.append(",");
			bW.append((CharSequence) (String.valueOf(value)));
			bW.newLine();
			entryCounter++;
			return true;
		} catch (IOException e) {
			loggingBox.setBackground(red);
			tGui.setMessageText(e.getMessage());
			return false;
		}
	}

	public void closeWriters() {
		try {
			bW.close();
			fW.close();
			loggingBox.setBackground(null);
		} catch (IOException e) {
			loggingBox.setBackground(red);
			tGui.setMessageText(e.getMessage());
		}

	}
}