/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package controller;

import gui.GeneralPreferencesWindow;
import gui.LimitsPreferencesWindow;
import gui.ThermoGui;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JTextField;

public class TempController extends Thread {

	private ThermoGui tGui;
	public boolean ready = true;
	private boolean online = true;
	public Map<Integer, RecordFileController> fileController = new LinkedHashMap<Integer, RecordFileController>();;
	public NotificationSender mS;
	public float[] tempValues = new float[8];
	webUpdater webUpdater;

	// Preferences
	int refreshInterval;
	String pathToLog;
	mbug_2818 mbug;
	boolean sendOnline;

	public TempController(ThermoGui gui) {
		tGui = gui;
		mS = new NotificationSender(gui, this);
		refreshInterval = gui.preferences.getInt("refInterval", 10) * 100;
		pathToLog = gui.preferences.get("pathLog", "");
		sendOnline = gui.preferences.getBoolean("sendOnline", false);
	}

	public void run() {
		mbug = new mbug_2818(this);
		mbug.open();
		getPreferences();
		if (sendOnline) {
			webUpdater = new webUpdater(tGui.preferences.get("sendOnlinePath",
					""), this);
		}
		while (tGui != null) {
			if (ready) {
				tempValues = mbug.readValues();
				if (mbug.isOpen()) {
					tGui.setTempAnzeige1(tempValue(tempValues[0]));
					tGui.setTempAnzeige2(tempValue(tempValues[1]));
					tGui.setTempAnzeige3(tempValue(tempValues[2]));
					tGui.setTempAnzeige4(tempValue(tempValues[3]));
					tGui.setTempAnzeige5(tempValue(tempValues[4]));
					tGui.setTempAnzeige6(tempValue(tempValues[5]));
					tGui.setTempAnzeige7(tempValue(tempValues[6]));
					tGui.setTempAnzeige8(tempValue(tempValues[7]));
				}
			}
			ready = false;
			if (online && mbug.isOpen()) {
				tGui.limitController();
				logController();
			}
			if (sendOnline && mbug.isOpen()) {
				if (webUpdater == null) {
					webUpdater = new webUpdater(tGui.preferences.get(
							"sendOnlinePath", ""), this);
				}
				webUpdater.sendDataOnline();
			} else {
				if (webUpdater != null) {
					webUpdater = null;
				}
			}
			getPreferences();
			try {
				sleep(refreshInterval);
			} catch (InterruptedException e) {
				tGui.setMessageText(e.getMessage());
			}

		}
		mbug.close();
	}

	private String tempValue(float value) {
		String result = "";
		if (value != -274.0) {
			result = String.valueOf(value);
		}
		return result;
	}

	public void checkLimits(float upperLimit, float lowerLimit,
			float actualValue, JTextField textField) {
		if (actualValue >= upperLimit) {
			Color bg = new Color(255, 0, 0);
			textField.setBackground(bg);
			mS.sendNotification(textField.getName(), actualValue, upperLimit);
		} else if (actualValue <= lowerLimit) {
			Color bg = new Color(255, 0, 0);
			textField.setBackground(bg);
			mS.sendNotification(textField.getName(), actualValue, lowerLimit);
		} else if (actualValue <= upperLimit && actualValue >= lowerLimit) {
			textField.setBackground(null);
		}
		ready = true;
	}

	public void logController() {
		boolean unixTime;
		unixTime = tGui.preferences.getBoolean("logUnixTime", false);
		for (Entry<Integer, JTextField> entry : tGui.loggedFields.entrySet()) {
			if (!fileController.containsKey(entry.getKey())) {
				RecordFileController rC = new RecordFileController(tGui,
						entry.getKey(), pathToLog, unixTime);
				fileController.put(entry.getKey(), rC);
			} else {
				RecordFileController rC = fileController.get(entry.getKey());
				rC.logToFile(Float.parseFloat(entry.getValue().getText()));
			}
		}

		for (Entry<Integer, RecordFileController> entry : fileController
				.entrySet()) {
			if (!tGui.loggedFields.containsKey(entry.getKey())) {
				entry.getValue().closeWriters();
				fileController.remove(entry.getKey());
			}
		}
	}

	public void getPreferences() {
		refreshInterval = tGui.preferences.getInt("refInterval", 10) * 100;
		pathToLog = tGui.preferences.get("pathLog", "");
		sendOnline = tGui.preferences.getBoolean("sendOnline", false);
	}

	public void openGeneralPrefWindow() {
		new GeneralPreferencesWindow(tGui);
	}

	public void openLimitsPrefWindow() {
		new LimitsPreferencesWindow(tGui, this);
	}

	public void openDialog(String text) {
		tGui.setMessageText(text);
	}
}
