/*
 	tG - ThermoGUI for mbug
    Copyright (C) 2011 Kamil Szepanski

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package controller;

import ch.ntb.usb.Device;
import ch.ntb.usb.USB;
import ch.ntb.usb.USBException;
import ch.ntb.usb.Usb_Config_Descriptor;
import ch.ntb.usb.Usb_Endpoint_Descriptor;
import ch.ntb.usb.Usb_Interface;
import ch.ntb.usb.Usb_Interface_Descriptor;

public class mbug_2818 {
	static Device dev;
	static int outAdress;
	static int inAdress;
	static int maxPackageSize;
	TempController tempC;
	static boolean open = false;

	public mbug_2818(TempController tC) {
		dev = USB.getDevice((short) 0x04d8, (short) 0xfbc3);
		tempC = tC;
	}

	public void open() {
		try {
			dev.open(1, 0, -1);
			Usb_Config_Descriptor[] uc = dev.getConfigDescriptors();
			Usb_Interface[] in = uc[0].getInterface();
			Usb_Interface_Descriptor[] inD = in[0].getAltsetting();
			Usb_Endpoint_Descriptor[] ep = inD[0].getEndpoint();

			outAdress = ep[0].getBEndpointAddress();
			inAdress = ep[1].getBEndpointAddress();
			maxPackageSize = ep[1].getWMaxPacketSize();

			open = true;
		} catch (USBException e) {
			tempC.openDialog(e.getMessage());
		}
	}
	
	public boolean isOpen(){
		if (dev.isOpen()){
			return true;
		}
		else {
			return false;
		}
	}

	public void close() {
		try {
			dev.close();
		} catch (USBException e) {
			tempC.openDialog(e.getMessage());
		}
	}

	public String readString() {
		String result = "";
		if (open) {
			byte[] c = new byte[] { (byte) 0xFB, (byte) 0xA0 };
			byte[] d = new byte[maxPackageSize];

			try {
				dev.writeInterrupt(outAdress, c, c.length, 1000, false);
				dev.readInterrupt(inAdress, d, d.length, 1000, false);
			} catch (USBException e) {
				e.printStackTrace();
			}

			for (byte b : d) {
				result += (char) b;
			}
			result = result.replaceAll(" ", "");
		} else {
			result = "Ger�t nicht initialisiert";
		}
		return result;
	}

	public float[] readValues() {
		float[] result = new float[8];
		if (open) {
			byte[] c = new byte[] { (byte) 0xFB, (byte) 0xA0 };
			byte[] d = new byte[maxPackageSize];

			try {
				dev.writeInterrupt(outAdress, c, c.length, 1000, false);
				dev.readInterrupt(inAdress, d, d.length, 1000, false);
			} catch (USBException e) {
				e.printStackTrace();
			}

			int i = 0;
			String value = "";
			int a = 0;
			for (byte b : d) {
				if (i != 7) {
					value += (char) b;
					i++;
				} else if (i == 7) {
					value = value.replaceAll(" ", "");
					if (!value.equals("-inf")) {
						result[a] = Float.parseFloat(value);
					} else {
						result[a] = -274f;
					}
					a++;
					i = 0;
					value = "";
				}
			}
		} else {
			result = null;
		}
		return result;
	}
}
